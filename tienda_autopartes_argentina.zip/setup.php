<?php
declare(strict_types=1);
require __DIR__ . '/includes.php';
secure_session();
$target = __DIR__ . '/data/admin.php';
$error = '';
if (is_file($target)) { http_response_code(403); exit('La configuración inicial ya fue realizada.'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) $error='Sesión vencida. Actualizá la página.';
    else {
        $pass=(string)($_POST['password']??''); $confirm=(string)($_POST['confirm']??'');
        if (strlen($pass)<12) $error='Usá al menos 12 caracteres.';
        elseif ($pass!==$confirm) $error='Las contraseñas no coinciden.';
        else {
            $hash=password_hash($pass, PASSWORD_DEFAULT);
            $content="<?php\nreturn " . var_export($hash, true) . ";\n";
            if (file_put_contents($target, $content, LOCK_EX)!==false) { @chmod($target,0600); header('Location: admin.php'); exit; }
            $error='No se pudo crear el archivo. Revisá los permisos de escritura de data.';
        }
    }
}
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Configuración inicial</title><link rel="stylesheet" href="assets/style.css"></head><body class="admin-body"><form class="admin-box setup-box" method="post"><span class="eyebrow">CONFIGURACIÓN ÚNICA</span><h1>Crear contraseña de administración</h1><p>Elegí una contraseña única de al menos 12 caracteres. No la compartas.</p><?php if($error): ?><p class="error"><?= h($error) ?></p><?php endif; ?><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><label>Contraseña<input type="password" name="password" minlength="12" required autocomplete="new-password"></label><label>Repetir contraseña<input type="password" name="confirm" minlength="12" required autocomplete="new-password"></label><button class="button">Crear acceso privado</button></form></body></html>
