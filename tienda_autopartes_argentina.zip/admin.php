<?php
declare(strict_types=1);
require __DIR__ . '/includes.php';
secure_session();
if (admin_hash() === '') { header('Location: setup.php'); exit; }
if (isset($_GET['logout'])) { $_SESSION=[]; session_destroy(); header('Location: admin.php'); exit; }
$error = '';
if (empty($_SESSION['admin'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
        if (!verify_csrf()) $error = 'La sesión venció. Actualizá la página e intentá otra vez.';
        elseif (password_verify((string)($_POST['password'] ?? ''), admin_hash())) { session_regenerate_id(true); $_SESSION['admin']=true; $_SESSION['csrf']=bin2hex(random_bytes(32)); header('Location: admin.php'); exit; }
        else { $error = 'Contraseña incorrecta.'; }
    }
    ?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Acceso administrador</title><link rel="stylesheet" href="assets/style.css"></head><body class="admin-body"><form class="admin-box" method="post"><span class="eyebrow">PANEL PRIVADO</span><h1>Administración</h1><p>Ingresá tu contraseña para administrar el catálogo.</p><?php if($error): ?><p class="error"><?= h($error) ?></p><?php endif; ?><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="password" name="password" placeholder="Contraseña" required autocomplete="current-password"><button class="button" name="login" value="1">Ingresar</button><a href="index.php">Volver a la tienda</a></form></body></html><?php exit;
}
$products = load_products(); $message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_product'])) {
    if (!verify_csrf()) $message = 'Sesión vencida. Recargá e intentá de nuevo.';
    else {
        $id = trim((string)($_POST['id'] ?? ''));
        $p = ['id'=>$id ?: bin2hex(random_bytes(6)), 'name'=>trim((string)($_POST['name'] ?? '')), 'brand'=>trim((string)($_POST['brand'] ?? '')), 'category'=>trim((string)($_POST['category'] ?? '')), 'description'=>trim((string)($_POST['description'] ?? '')), 'image'=>trim((string)($_POST['image'] ?? '')), 'active'=>isset($_POST['active'])];
        if ($p['name'] === '' || !in_array($p['category'], categories(), true)) $message = 'Completá el nombre y elegí una categoría válida.';
        elseif ($p['image'] !== '' && !filter_var($p['image'], FILTER_VALIDATE_URL)) $message = 'La imagen debe ser una URL válida o dejarse vacía.';
        else {
            $found=false;
            foreach($products as $i=>$old) if(($old['id']??'')===$p['id']) {$products[$i]=$p;$found=true;break;}
            if(!$found) $products[]=$p;
            $message = save_products($products) ? 'Producto guardado correctamente.' : 'No se pudo guardar. Revisá permisos de la carpeta data.';
        }
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    if (!verify_csrf()) $message='Sesión vencida.';
    else { $products=array_values(array_filter($products,fn($p)=>($p['id']??'')!==(string)$_POST['delete_id'])); $message=save_products($products)?'Producto eliminado.':'No se pudo guardar.'; }
}
$edit = null;
if (isset($_GET['edit'])) foreach($products as $p) if(($p['id']??'')===$_GET['edit']) $edit=$p;
$edit = $edit ?: ['id'=>'','name'=>'','brand'=>'','category'=>categories()[0],'description'=>'','image'=>'','active'=>true];
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Panel | <?= h(SITE_NAME) ?></title><link rel="stylesheet" href="assets/style.css"></head><body class="admin-body"><main class="admin-wrap"><div class="admin-head"><div><span class="eyebrow">PANEL DE CONTROL</span><h1>Administrar catálogo</h1></div><a href="admin.php?logout=1">Cerrar sesión</a></div><?php if($message): ?><p class="notice"><?= h($message) ?></p><?php endif; ?>
<div class="admin-columns"><form class="admin-box" method="post"><h2><?= $edit['id']?'Editar producto':'Agregar producto' ?></h2><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="hidden" name="id" value="<?= h($edit['id']) ?>"><label>Nombre del repuesto<input name="name" required maxlength="120" value="<?= h($edit['name']) ?>"></label><label>Marca<input name="brand" maxlength="80" value="<?= h($edit['brand']) ?>" placeholder="Ej. Bosch, SKF, Valeo"></label><label>Categoría<select name="category"><?php foreach(categories() as $c): ?><option <?= $edit['category']===$c?'selected':'' ?>><?= h($c) ?></option><?php endforeach; ?></select></label><label>Descripción<textarea name="description" rows="3" maxlength="500"><?= h($edit['description']) ?></textarea></label><label>URL de imagen (opcional)<input name="image" type="url" value="<?= h($edit['image']) ?>" placeholder="https://..."></label><label class="check"><input type="checkbox" name="active" <?= !empty($edit['active'])?'checked':'' ?>> Publicar en la tienda</label><button class="button" name="save_product" value="1">Guardar producto</button><?php if($edit['id']): ?><a href="admin.php">Cancelar edición</a><?php endif; ?></form>
<section class="admin-box"><h2>Productos (<?= count($products) ?>)</h2><?php if(!$products): ?><p>Todavía no cargaste productos. Agregá el primero desde el formulario.</p><?php endif; ?><?php foreach($products as $p): ?><div class="admin-product"><div><b><?= h($p['name']??'') ?></b><small><?= h($p['category']??'') ?> · <?= !empty($p['active'])?'Publicado':'Oculto' ?></small></div><a href="admin.php?edit=<?= rawurlencode($p['id']) ?>">Editar</a><form method="post" onsubmit="return confirm('¿Eliminar este producto?')"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="hidden" name="delete_id" value="<?= h($p['id']) ?>"><button class="danger">Eliminar</button></form></div><?php endforeach; ?></section></div><p class="admin-foot"><a href="index.php">← Ver tienda</a> · Los pedidos se coordinan directamente por WhatsApp. No se almacenan datos de tarjetas ni pagos en esta web.</p></main></body></html>
