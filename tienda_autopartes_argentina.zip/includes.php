<?php
declare(strict_types=1);
define('SITE_NAME', 'Repuestos Online');
define('SITE_URL', 'https://tudominio.com');
define('WHATSAPP_NUMBER', '5492804866176');
define('DATA_FILE', __DIR__ . '/data/products.json');
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function categories(): array { return ['Frenos','Filtros','Embragues','Ópticas y faros','Suspensión y dirección','Motor','Electricidad','Carrocería']; }
function category_icon(int $i): string { return ['◉','▤','⚙','◈','⌁','◌','ϟ','▱'][$i] ?? '⚙'; }
function load_products(): array {
    if (!is_file(DATA_FILE)) return [];
    $raw = file_get_contents(DATA_FILE);
    $data = json_decode($raw ?: '[]', true);
    return is_array($data) ? $data : [];
}
function save_products(array $products): bool {
    $json = json_encode(array_values($products), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents(DATA_FILE, $json . PHP_EOL, LOCK_EX) !== false;
}
function admin_hash(): string {
    $cfg = __DIR__ . '/data/admin.php';
    if (!is_file($cfg)) return '';
    $value = include $cfg;
    return is_string($value) ? $value : '';
}
function secure_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Strict']);
    session_start();
}
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(): bool {
    return isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], (string)$_POST['csrf']);
}
